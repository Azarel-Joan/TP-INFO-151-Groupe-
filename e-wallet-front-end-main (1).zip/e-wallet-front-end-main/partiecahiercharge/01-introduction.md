# 1. Introduction

## 1.1 Objet

Ce document (SRS) décrit le but, les fonctionnalités, les interfaces et les critères de performance du système de change et de portefeuilles multi-devises **FX-Wallet Manager**. Il constitue la spécification de référence pour la conception, le développement et les tests de l'application.

## 1.2 Présentation du projet

Un portefeuille numérique permet de détenir des soldes dans plusieurs devises et de transférer de l'argent à d'autres utilisateurs ou à des marchands. Dans ce projet, un expéditeur au Cameroun peut payer en XAF tandis que le destinataire reçoit le montant correspondant en USD ou en EUR.

Le projet consiste à concevoir une **application console** permettant aux utilisateurs de gérer des portefeuilles numériques, d'effectuer des transferts d'argent simulés et de convertir des montants entre plusieurs devises. L'application calcule de façon transparente la conversion, les frais de transaction, la taxe, les soldes et les enregistrements de transactions. Les données sont conservées de façon locale.

Il s'agit d'une **simulation pédagogique** : elle ne se connecte à aucune banque, aucun réseau de cartes ni aucun opérateur de mobile money, et ne manipule aucun fonds réel.

## 1.3 Objectifs

**Objectif principal.** Développer une application qui facilite la gestion des portefeuilles et des transactions financières, avec une logique métier correcte, des calculs exacts, une validation rigoureuse, une conception orientée objet et une persistance des données.

**Objectifs spécifiques :**

- créer et gérer des utilisateurs ;
- créer des portefeuilles et consulter les soldes ;
- convertir des montants entre différentes devises ;
- calculer les frais, la taxe et les commissions ;
- effectuer des transferts entre utilisateurs ;
- consulter l'historique des transactions et générer des rapports.

## 1.4 Portée du projet

L'application permet de gérer **trois devises** (XAF, USD, EUR) avec conversion, transfert, historique et rapports. Elle n'est **pas** un service de paiement en production.

**Inclus dans le périmètre :**

- portefeuilles multi-devises ;
- gestion des taux ;
- transferts et paiements marchands ;
- calcul des frais, de la taxe et de la commission ;
- reçus et historique ;
- rapports journaliers et mensuels ;
- sauvegarde locale des données.

**Hors périmètre :**

- connexion à de vraies banques, cartes bancaires ou mobile money ;
- fonds réels ;
- taux de change en temps réel ;
- conseil juridique ou fiscal ;
- déploiement en production.

## 1.5 Public visé

Encadreur (examinateur), développeurs, testeurs et utilisateur final dans un cadre pédagogique.

## 1.6 Conventions et définitions

| Terme | Signification | Terme | Signification |
|-------|---------------|-------|---------------|
| EF   | Exigence fonctionnelle | XAF  | Franc CFA |
| ENF  | Exigence non fonctionnelle | USD  | Dollar américain |
| Prio | Priorité | EUR  | Euro |
| Dép  | Dépendance | Desc | Description |
| P2P  | Pair à pair (entre utilisateurs) | SRS  | Software Requirements Specification |

## 1.7 Références

- IEEE 830 — Recommended Practice for Software Requirements Specifications ;
- Sujet du TP INF151 — « Multi-Currency Digital Wallet and Foreign Exchange Conversion System » ;
- README du projet.
