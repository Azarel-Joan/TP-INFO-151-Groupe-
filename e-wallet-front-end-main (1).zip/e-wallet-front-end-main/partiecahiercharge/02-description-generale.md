# 2. Description générale

## 2.1 Perspective du produit

Application autonome (*standalone*) fonctionnant sur un système d'exploitation de bureau standard, utilisée en mode console. L'installation et le lancement sont décrits dans le README. Aucune API externe n'est utilisée : tout fonctionne en local.

## 2.2 Fonctionnalités principales

L'application devra permettre de :

1. créer et identifier les utilisateurs ;
2. configurer les taux de change ;
3. gérer les portefeuilles et leurs soldes ;
4. convertir les devises grâce aux taux de change ;
5. effectuer des transferts (P2P) et des paiements marchands ;
6. calculer automatiquement les frais, la taxe et la commission ;
7. vérifier que le solde est suffisant avant chaque opération ;
8. enregistrer les transactions et produire des reçus ;
9. générer des rapports journaliers et mensuels ;
10. sauvegarder les données.

## 2.3 Classes d'utilisateurs

| Acteur | Rôle dans le système |
|--------|----------------------|
| **Client** (User) | Consulte les soldes de ses portefeuilles, effectue des transferts, consulte son historique et affiche ou imprime un reçu. |
| **Administrateur** (Admin) | Gère les taux de change, les paramètres de frais et les utilisateurs ; consulte les rapports journaliers et mensuels. |
| **Marchand** (Merchant) | Reçoit des paiements et consulte les commissions qui lui sont appliquées. |

## 2.4 Environnement d'exploitation

- Systèmes : Windows, macOS, Linux ;
- Langage : Java 17+ (calculs monétaires avec *BigDecimal*) ou Python 3.10+ (module *decimal*) ;
- Stockage local : SQLite ou MySQL (ou fichiers locaux), selon le choix documenté dans le README.

## 2.5 Contraintes

- Les taux de change sont saisis manuellement (taux simulés) ; ils ne sont pas des taux de marché en temps réel ;
- La taxe de 19,25 % est configurable (hypothèse de TP) ;
- Fonds simulés uniquement ;
- Les montants monétaires n'utilisent jamais *float* ni *double*.

## 2.6 Documentation

README, manuel utilisateur, diagrammes UML (cas d'utilisation, classes, séquence) et schéma de base de données.

## 2.7 Hypothèses de travail

- trois devises au maximum : XAF, USD et EUR ;
- le solde d'un portefeuille n'est jamais négatif ;
- les taux sont stockés dans le sens source → cible.
