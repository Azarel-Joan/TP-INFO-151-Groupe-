---
title: "FX-Wallet Manager — Cahier des charges fonctionnel (SRS)"
subtitle: "Portefeuille numérique multi-devises et système de conversion de devises"
date: "29 octobre 2026"
lang: fr
---

**RÉPUBLIQUE DU CAMEROUN** — *Paix – Travail – Patrie*
**UNIVERSITÉ DE YAOUNDÉ I** — Faculté des Sciences — Département d'Informatique

**INF151 — Introduction au génie logiciel | TP | Session 2026/2027**

# CAHIER DES CHARGES FONCTIONNEL (SRS)

## FX-Wallet Manager

Portefeuille numérique multi-devises et système de conversion de devises

*Projet pédagogique — fonds simulés uniquement — Version 1.0 — 29 octobre 2026*

**Examinateur :** Pr. Kimbi Xaveria

**Membres du groupe :**

| N° | Nom et prénom | Matricule |
|----|---------------|-----------|
| 1  |               |           |
| 2  |               |           |
| 3  |               |           |
| 4  |               |           |
| 5  |               |           |
