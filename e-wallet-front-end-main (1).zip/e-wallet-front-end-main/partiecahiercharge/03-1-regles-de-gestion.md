# 3. Exigences détaillées

## 3.1 Règles de gestion et formules

Les règles ci-dessous s'appliquent à l'ensemble des exigences fonctionnelles. Les valeurs de frais, de taxe et de commission sont des **hypothèses de TP**, configurables, et ne constituent pas un conseil juridique ou fiscal.

| Réf. | Règle | Formule / valeur par défaut |
|------|-------|-----------------------------|
| **RG-01** | Devises utilisées : XAF, USD et EUR, sauf indication contraire. | — |
| **RG-02** | Frais de transaction = frais en pourcentage + frais fixes. Les frais fixes de 100 XAF sont convertis si la devise source n'est pas le XAF. | frais = montant source × 2,5 % + 100 XAF |
| **RG-03** | Taxe calculée sur les frais de transaction (hypothèse de TP, configurable). | taxe = frais × 19,25 % |
| **RG-04** | Débit total de l'expéditeur. | débit = montant source + frais + taxe |
| **RG-05** | Conversion selon la table des taux (taux source → cible). Si 1 USD = 600 XAF, alors XAF → USD s'obtient par division. | montant USD = montant XAF ÷ 600 |
| **RG-06** | Commission marchand : appliquée uniquement aux paiements marchands, séparée des frais et de la taxe, déduite du règlement du marchand. | commission = montant converti × 1 %<br>marchand reçoit = montant converti − commission |
| **RG-07** | Un transfert est refusé si le solde disponible est insuffisant. | solde ≥ débit total |
| **RG-08** | Une opération échouée ne modifie aucun solde. | aucun débit, aucun crédit |
| **RG-09** | Arrondi : calculs en précision décimale élevée, arrondi uniquement au règlement, mode HALF_UP, selon les décimales de la devise (XAF : 0 ; USD et EUR : 2). | voir Annexe A |
